#include "Main.h"

void MainApp::resetCamera(){
	position = vec3(992, 120, 0);
	wx = 0.45f;
	wy = PI / 2;
	wz = 0;
}

void MainApp::processMovement(const vec3 &newPosition){
	position = clamp(newPosition, vec3(-992, -224, -480), vec3(992, 224, 480));
}

void MainApp::setButton(unsigned int button, bool value){
	if (button == MOUSE_LEFT){
		static float t;
		if (value){
			t = time;
		} else {
			vec3 view = vec3(modelView.elem[2][0], modelView.elem[2][1], modelView.elem[2][2]);

			for (unsigned int i = 0; i < COUNT; i++){
				vec3 v = spheres[i].pos - position;
				float len = length(v);

				if (len < 200 && dot(v, view) > 0.7f * len){
					spheres[i].dir += 1000 * (time - t) * view;
				}
			}
		}
	}
	App::setButton(button, value);
}

void subDivide(vec3 *&dest, const vec3 &v0, const vec3 &v1, const vec3 &v2, int level){
	if (level){
		vec3 v3 = normalize(v0 + v1);
		vec3 v4 = normalize(v1 + v2);
		vec3 v5 = normalize(v2 + v0);

		subDivide(dest, v0, v3, v5, level - 1);
		subDivide(dest, v3, v4, v5, level - 1);
		subDivide(dest, v3, v1, v4, level - 1);
		subDivide(dest, v5, v4, v2, level - 1);
	} else {
		*dest++ = v0;
		*dest++ = v1;
		*dest++ = v2;
	}
}

bool MainApp::init(){
	vec3 *sphere = new vec3[SPHERE_SIZE];
	vec3 *dest = sphere;

	subDivide(dest, vec3(0, 1,0), vec3( 0,0, 1), vec3( 1,0, 0), SUBDIV_LEVEL);
	subDivide(dest, vec3(0, 1,0), vec3( 1,0, 0), vec3( 0,0,-1), SUBDIV_LEVEL);
	subDivide(dest, vec3(0, 1,0), vec3( 0,0,-1), vec3(-1,0, 0), SUBDIV_LEVEL);
	subDivide(dest, vec3(0, 1,0), vec3(-1,0, 0), vec3( 0,0, 1), SUBDIV_LEVEL);

	subDivide(dest, vec3(0,-1,0), vec3( 1,0, 0), vec3( 0,0, 1), SUBDIV_LEVEL);
	subDivide(dest, vec3(0,-1,0), vec3( 0,0, 1), vec3(-1,0, 0), SUBDIV_LEVEL);
	subDivide(dest, vec3(0,-1,0), vec3(-1,0, 0), vec3( 0,0,-1), SUBDIV_LEVEL);
	subDivide(dest, vec3(0,-1,0), vec3( 0,0,-1), vec3( 1,0, 0), SUBDIV_LEVEL);

	model = new OpenGLModel();
	OpenGLBatch *batch = new OpenGLBatch();

	batch->addFormat(ATT_VERTEX, ATT_FLOAT, 3, 0);
	batch->setPrimitiveType(PRIM_TRIANGLES);
	batch->setVertices(sphere, SPHERE_SIZE, sizeof(vec3));
	batch->optimize(SPHERE_SIZE);
	model->addBatch(batch);

	srand((unsigned int) cpuHz);

	for (unsigned int i = 0; i < COUNT; i++){
		spheres[i].pos = 256 * (vec3(4 * float(rand()), float(rand()), 2 * float(rand())) * (2.0f / RAND_MAX) - vec3(4,1,2));
		spheres[i].size = 30.0f + (rand() % 65);
		spheres[i].dir = vec3(float(rand()), float(rand()), float(rand())) * (2.0f / RAND_MAX) - 1.0f;
		spheres[i].dir *= 400;

		int k = (i % 7) + 1;
		spheres[i].color = vec3(float(k & 1), float((k >> 1) & 1), float((k >> 2) & 1));
	}

	spheres[SPHERE_COUNT].size = 60.0f;

	return true;
}

bool MainApp::exit(){
	delete model;
	return true;
}

bool MainApp::load(){
	if (!GL_ARB_shader_objects_supported || !GL_ARB_vertex_shader_supported || !GL_ARB_fragment_shader_supported || !GL_ARB_shading_language_100_supported){
		addToLog("No GLSL support (GL_ARB_shader_objects, GL_ARB_vertex_shader, GL_ARB_fragment_shader, GL_ARB_shading_language_100)\n");
		return false;
	}

	if ((shadow = renderer->addShader("shadow.shd", "#define SHADOW_SOFTNESS 0.0005\n"DEFINE_STR(SPHERE_COUNT))) == SHADER_NONE) return false;
	if ((room = renderer->addShader("room.shd")) == SHADER_NONE) return false;
	if ((roomAmbient = renderer->addShader("roomAmbient.shd")) == SHADER_NONE) return false;
	if ((sphere = renderer->addShader("sphere.shd")) == SHADER_NONE) return false;
	if ((sphereAmbient = renderer->addShader("sphereAmbient.shd")) == SHADER_NONE) return false;

	const char *attribs[] = { "textureCoord", "tangent", "binormal", "normal" };
	if (!((OpenGLRenderer *) renderer)->changeShaderAttribs(room,        attribs, 1, sizeof(attribs) / sizeof(char *))) return false;
	if (!((OpenGLRenderer *) renderer)->changeShaderAttribs(roomAmbient, attribs, 1, sizeof(attribs) / sizeof(char *))) return false;


	setDefaultFont("../Textures/Fonts/Future.font", "../Textures/Fonts/Future.dds");

	if ((base[0] = renderer->addTexture("../Textures/Tx_imp_wall_01_small.dds")) == TEXTURE_NONE) return false;
	if ((bump[0] = renderer->addTexture("../Textures/Tx_imp_wall_01Bump.png", TEX_NORMALMAP)) == TEXTURE_NONE) return false;

	if ((base[1] = renderer->addTexture("../Textures/StoneWall_1-2.dds")) == TEXTURE_NONE) return false;
	if ((bump[1] = renderer->addTexture("../Textures/StoneWall_1-2Bump.png", TEX_NORMALMAP)) == TEXTURE_NONE) return false;

	if ((base[2] = renderer->addTexture("../Textures/synbr01.dds")) == TEXTURE_NONE) return false;
	if ((bump[2] = renderer->addTexture("../Textures/synbr01Bump.png", TEX_NORMALMAP)) == TEXTURE_NONE) return false;

	unsigned char pixels[64][64];
	for (int x = 0; x < 64; x++){
		for (int y = 0; y < 64; y++){
			float fx = float(x) / 63.0f * 2 - 1;
			float fy = float(y) / 63.0f * 2 - 1;
			float r = saturate(1 - (fx * fx + fy * fy));
			pixels[y][x] = (unsigned char) (255.0f * r);
		}		
	}

	Image *image = new Image();
	image->loadFromMemory(pixels, 64, 64, FORMAT_I8, false, false);

	if ((light = renderer->addTexture(image, TEX_CLAMP)) == TEXTURE_NONE) return false;

	return true;
}

bool MainApp::unload(){
	return true;
}

void MainApp::doPhysics(const float frameTime){
	static vec3 gravity(0, -500, 0);
	static vec3 planeNormals[6] = { vec3(0, 1, 0), vec3(0, -1, 0), vec3(0, 0, -1), vec3(0, 0, 1), vec3(1, 0, 0), vec3(-1, 0, 0) };
	static float planeOffsets[6] = { 256, 256, 512, 512, 1024, 1024 };
	unsigned int i, j;

	for (i = 0; i < COUNT; i++){
		//spheres[i].dir *= powf(0.95f, frameTime);
		spheres[i].dir += frameTime * gravity;
		spheres[i].pos += frameTime * spheres[i].dir;
	}

	for (i = 0; i < COUNT; i++){
		for (j = 0; j < 6; j++){
			float dist = dot(spheres[i].pos, planeNormals[j]) + planeOffsets[j];
			if (dist < spheres[i].size){
				spheres[i].dir = 0.95f * reflect(spheres[i].dir, planeNormals[j]);
				spheres[i].pos += (spheres[i].size - dist) * planeNormals[j];
			}
		}
		for (j = i + 1; j < COUNT; j++){
			vec3 n = spheres[i].pos - spheres[j].pos;
			float dist = length(n);

			float push = spheres[i].size + spheres[j].size - dist;

			if (push > 0){
				n *= (1.0f / dist);

				float invMassI = 1.0f / (spheres[i].size * spheres[i].size * spheres[i].size);
				float invMassJ = 1.0f / (spheres[j].size * spheres[j].size * spheres[j].size);

				spheres[i].pos += 0.5f * push * n;
				spheres[j].pos -= 0.5f * push * n;

				float e = 0.8f;
				float c = -(1 + e) * dot(spheres[i].dir - spheres[j].dir, n) / (dot(n, n) * (invMassI + invMassJ));

				spheres[i].dir = spheres[i].dir + c * invMassI * n;
				spheres[j].dir = spheres[j].dir - c * invMassJ * n;
			}
		}
	}
}

void MainApp::drawLight(const vec3 &lightPos, const float size){
	renderer->setBlending(GL_ONE, GL_ONE);
	renderer->setTextures(light);
	renderer->setMask(COLOR);
	renderer->apply();

	glColor3f(1, 1, 1);

	vec3 dx(modelView.elem[0][0], modelView.elem[0][1], modelView.elem[0][2]);
	vec3 dy(modelView.elem[1][0], modelView.elem[1][1], modelView.elem[1][2]);
	glBegin(GL_QUADS);
		glTexCoord2f(0,0);
		glVertex3fv(lightPos - size * dx + size * dy);

		glTexCoord2f(1,0);
		glVertex3fv(lightPos + size * dx + size * dy);

		glTexCoord2f(1,1);
		glVertex3fv(lightPos + size * dx - size * dy);

		glTexCoord2f(0,1);
		glVertex3fv(lightPos - size * dx - size * dy);
	glEnd();
}

void MainApp::drawRoom(int pass){
	static float vertexArray[24 * 3] = {
		-1024, -256,  512,  1024, -256,  512,  1024, -256, -512, -1024, -256, -512, -1024,  256, -512,  1024,  256, -512,
		 1024,  256,  512, -1024,  256,  512, -1024,  256,  512,  1024,  256,  512,  1024, -256,  512, -1024, -256,  512,
		 1024,  256, -512, -1024,  256, -512, -1024, -256, -512,  1024, -256, -512, -1024,  256, -512, -1024,  256,  512,
		-1024, -256,  512, -1024, -256, -512,  1024,  256,  512,  1024,  256, -512,  1024, -256, -512,  1024, -256,  512,
	};
	static float texCoordArray[24 * 2] = {
		-2, 1,  2, 1,  2, -1, -2, -1, -2, 1,  2, 1,  2, -1, -2, -1, -2, 1,  2, 1,  2, 0, -2, 0,
		 2, 0, -2, 0, -2,  1,  2,  1,  1, 0, -1, 0, -1,  1,  1,  1,  1, 0, -1, 0, -1, 1,  1, 1,
	};
	static float tangentArray[24 * 3] = {
		1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0,  0, 1, 0,  0, 1, 0,  0, 1, 0,  0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0,
		1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, -1, 0, 0, -1, 0, 0, -1, 0, 0, -1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1,
	};
	static float binormalArray[24 * 3] = {
		0,  0, 1, 0,  0, 1, 0,  0, 1, 0,  0, 1, 0,  0, -1, 0,  0, -1, 0,  0, -1, 0,  0, -1, 0,  1, 0, 0,  1, 0, 0,  1, 0, 0,  1, 0,
		0, -1, 0, 0, -1, 0, 0, -1, 0, 0, -1, 0, 0, -1,  0, 0, -1,  0, 0, -1,  0, 0, -1,  0, 0, -1, 0, 0, -1, 0, 0, -1, 0, 0, -1, 0,
	};
	static float normalArray[24 * 3] = {
		0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, -1, 0, 0, -1, 0, 0, -1, 0, 0, -1, 0,  0, 0, -1,  0, 0, -1,  0, 0, -1,  0, 0, -1,
		0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 1,  0, 0, 1,  0, 0, 1,  0, 0, 1,  0, 0, -1, 0,  0, -1, 0,  0, -1, 0,  0, -1, 0,  0,
	};

	glEnableClientState(GL_VERTEX_ARRAY);
	glVertexPointer(3, GL_FLOAT, 0, vertexArray);

	if (pass != 1){
		glEnableVertexAttribArrayARB(1);
		glVertexAttribPointerARB(1, 2, GL_FLOAT, GL_FALSE, 0, texCoordArray);

		if (pass != 0){
			glEnableVertexAttribArrayARB(2);
			glEnableVertexAttribArrayARB(3);
			glEnableVertexAttribArrayARB(4);
			
			glVertexAttribPointerARB(2, 3, GL_FLOAT, GL_FALSE, 0, tangentArray);
			glVertexAttribPointerARB(3, 3, GL_FLOAT, GL_FALSE, 0, binormalArray);
			glVertexAttribPointerARB(4, 3, GL_FLOAT, GL_FALSE, 0, normalArray);
		}
	}

	if (pass == 1){
		glDrawArrays(GL_QUADS, 0, 24);
	} else {
		static int n[] = { 2, 1, 0, 0, 0, 0 };
		for (int i = 0; i < 6; i++){
			if (pass == 0){
				renderer->setShader(roomAmbient);
				renderer->setTexture("Base", base[n[i]]);
				renderer->apply();
			} else {
				renderer->setShader(room);
				renderer->setTexture("Base", base[n[i]]);
				renderer->setTexture("Bump", bump[n[i]]);
				renderer->setBlending(DST_ALPHA, ONE);
				renderer->setMask(COLOR);
				renderer->apply();

				renderer->changeShaderConstant3f("lightPos", spheres[SPHERE_COUNT].pos);
				renderer->changeShaderConstant3f("camPos", position);
			}
			glDrawArrays(GL_QUADS, 4 * i, 4);
		}
	}

	if (pass != 1){
		if (pass != 0){
			glDisableVertexAttribArrayARB(4);
			glDisableVertexAttribArrayARB(3);
			glDisableVertexAttribArrayARB(2);
		}
		glDisableVertexAttribArrayARB(1);
	}
	glDisableClientState(GL_VERTEX_ARRAY);
}

void MainApp::drawSpheres(int pass){
	if (pass == 0){
		renderer->setShader(sphereAmbient);
		renderer->apply();
	} else if (pass == 1){

	} else {
		renderer->setShader(sphere);
		renderer->setBlending(DST_ALPHA, ONE);
		renderer->setMask(COLOR);
		renderer->apply();

		renderer->changeShaderConstant3f("camPos", position);
	}

	renderer->changeShaderConstant3f("lightPos", spheres[SPHERE_COUNT].pos);
	for (unsigned int i = 0; i < SPHERE_COUNT; i++){
		renderer->changeShaderConstant3f("offset", spheres[i].pos);
		renderer->changeShaderConstant1f("scale", spheres[i].size);
		renderer->changeShaderConstant4f("color", vec4(spheres[i].color, 1.0f));

		model->draw();
	}
}

bool MainApp::drawFrame(){
	renderer->changeMask(ALL);
	glClear(GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_PROJECTION);
	projection = projectionMatrixX(1.5f, float(height) / float(width), 0.1f, 6000);
	glLoadMatrixf(transpose(projection));

	modelView = rotateZXY(-wx, -wy, -wz);
	modelView.translate(-position);

	glMatrixMode(GL_MODELVIEW);
	glLoadMatrixf(transpose(modelView));

	doPhysics(min(frameTime, 0.1f));

	glEnable(GL_CULL_FACE);



	// Pass 0, ambient lighting + depth
	drawSpheres(0);
	drawRoom(0);



	// Pass 1, shadows
	vec4 spherePos[SPHERE_COUNT];
	for (unsigned int j = 0; j < SPHERE_COUNT; j++){
		spherePos[j] = vec4(spheres[j].pos, spheres[j].size * spheres[j].size);
	}

	renderer->setShader(shadow);
	renderer->setMask(ALPHA);
	renderer->apply();

	renderer->changeShaderConstant3f("lightPos", spheres[SPHERE_COUNT].pos);
	renderer->changeShaderConstantArray4f("spherePos", spherePos, SPHERE_COUNT);
	renderer->changeShaderConstant1f("scale", 1.0f);
	renderer->changeShaderConstant3f("offset", vec3(0, 0, 0));

	drawRoom(1);

	for (unsigned int i = 0; i < SPHERE_COUNT; i++){
		renderer->changeShaderConstant1f("scale",  spheres[i].size);
		renderer->changeShaderConstant3f("offset", spheres[i].pos);

		// Quick and dirty hack to avoid spheres to self shadow
		char str[16];
		sprintf(str, "spherePos[%d]", i);
		spherePos[i].w = -1e5;
		renderer->changeShaderConstant4f(str, spherePos[i]);

		model->draw();

		spherePos[i].w = spheres[i].size * spheres[i].size;
		renderer->changeShaderConstant4f(str, spherePos[i]);
	}

	// Pass 2, lighting
	drawSpheres(2);
	drawRoom(2);


	drawLight(spheres[SPHERE_COUNT].pos, spheres[SPHERE_COUNT].size);

	return true;
}

App *app = new MainApp();
