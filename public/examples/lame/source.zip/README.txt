Install i686 MinGW GCC, make and Python 3. Rebuild: python3 scripts/build-lame.py --source-archive lame-3.100.tar.gz
The source is unchanged. See BUILD.json for the pinned source, compiler and exact encoder options.
