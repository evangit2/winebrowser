#!/bin/sh
set -eu
cd "$(dirname "$0")"
cp DX12Lib/resource.h 'DX12Lib/src/..\resource.h'
"${CXX:-i686-w64-mingw32-g++}" '-std=c++17' '-O1' '-fpermissive' '-DUNICODE' '-D_UNICODE' '-DNDEBUG' '-D_XM_NO_INTRINSICS_' '-static' '-static-libgcc' '-static-libstdc++' '-include' './compat.h' '-include' './DX12Lib/inc/DX12LibPCH.h' '-I./header-compat' '-I./DirectXMath/Inc' '-I./DX12Lib/inc' '-I./Tutorial2/inc' '-Wl,--no-insert-timestamp' '-municode' '-mwindows' '-o' './Tutorial2.exe' './DX12Lib/src/Application.cpp' './DX12Lib/src/CommandQueue.cpp' './DX12Lib/src/DX12LibPCH.cpp' './DX12Lib/src/Game.cpp' './DX12Lib/src/HighResolutionClock.cpp' './DX12Lib/src/Window.cpp' './Tutorial2/src/Tutorial2.cpp' './Tutorial2/src/main.cpp' '-ld3d12' '-ldxgi' '-ld3dcompiler' '-ldxguid' '-lshlwapi'
