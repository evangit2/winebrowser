#include "Rail.h"

D3DVERTEXELEMENT9 vForm[] = {
	{ 0, 0,            D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0},
	{ 0, sizeof(vec3), D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_NORMAL,   0},
	D3DDECL_END()
};

bool Rail::load(LPDIRECT3DDEVICE9 dev, Renderer *renderer){
	continuous = false;

	dev->CreateVertexDeclaration(vForm, &vDecl);

	model = new Model();
	//model->loadObj("Bana.obj");
	model->loadFromFile("Bana.hmdl");
	/*model->getBatch(0)->reverseWinding();

	model->getBatch(0)->transform(mat4(
		1,0,0,3,
		0,1,0,0,
		0,0,1,0,
		0,0,0,1), ATT_VERTEX);
	model->getBatch(0)->transform(mat4(
		0,0,1,0,
		0,1,0,0,
		1,0,0,0,
		0,0,0,1), ATT_VERTEX);
	model->getBatch(0)->transform(mat4(
		10,0,0,0,
		0,10,0,0,
		0,0,10,0,
		0,0,0,1), ATT_VERTEX);

	model->getBatch(0)->transform(mat4(
		0,0,1,0,
		0,1,0,0,
		1,0,0,0,
		0,0,0,1), ATT_NORMAL);
*/

	/*model->getBatch(0)->removeAttribute(ATT_NORMAL);
	model->getBatch(0)->addNormals();
	model->getBatch(0)->flipNormals();
	*/


	/*model->getBatch(0)->removeAttribute(ATT_TEXCOORD);
	model->getBatch(0)->optimize();
	model->saveToFile("C:\\Documents and Settings\\Humus\\Skrivbord\\Bana.hmdl");
	*/

	Batch *batch = model->getBatch(0);
	unsigned int vSize = batch->getVertexCount() * batch->getVertexSize();
	unsigned int iSize = batch->getIndexCount() * batch->getIndexSize();

	float *dest;
	dev->CreateVertexBuffer(vSize, D3DUSAGE_WRITEONLY, 0, D3DPOOL_MANAGED, &vBuf, NULL);
	vBuf->Lock(0, 0, (void **) &dest, 0);
	memcpy(dest, batch->getVertices(), vSize);
	vBuf->Unlock();

	dev->CreateIndexBuffer(iSize, D3DUSAGE_WRITEONLY, D3DFMT_INDEX16, D3DPOOL_MANAGED, &iBuf, NULL);
	iBuf->Lock(0, 0, (void **) &dest, 0);
	memcpy(dest, batch->getIndices(), iSize);
	iBuf->Unlock();


	dev->CreateVertexBuffer(17 * 12 * sizeof(float), D3DUSAGE_WRITEONLY, 0, D3DPOOL_MANAGED, &vBuf2, NULL);
	vBuf2->Lock(0, 0, (void **) &dest, 0);
	for (unsigned int i = 0; i <= 16; i++){
		float x = cosf(i * 2 * PI / 16);
		float z = sinf(i * 2 * PI / 16);
		*dest++ = 8 * x;
		*dest++ = -1500;
		*dest++ = 8 * z;
		*dest++ = x;
		*dest++ = 0;
		*dest++ = z;
		*dest++ = 8 * x;
		*dest++ = 0;
		*dest++ = 8 * z;
		*dest++ = x;
		*dest++ = 0;
		*dest++ = z;
	}		
	vBuf2->Unlock();

	if ((railShader = renderer->addShader("RailShader.shd")) == SHADER_NONE) return false;
	if ((woodShader = renderer->addShader("WoodShader.shd")) == SHADER_NONE) return false;

	return true;
}

bool Rail::unload(){
	vDecl->Release();
	vBuf->Release();
	iBuf->Release();
	vBuf2->Release();

	delete model;

	return true;
}

void Rail::draw(LPDIRECT3DDEVICE9 dev, Renderer *renderer, const mat4 &mvp, const vec3 &position, TextureID env, TextureID noise){
	renderer->setShader(railShader);
	renderer->setTextures(env, noise);
	renderer->apply();

	renderer->changeShaderConstant4x4f("view_proj_matrix", mvp);
	renderer->changeShaderConstant3f("position", position);

	Batch *batch = model->getBatch(0);

	dev->SetVertexDeclaration(vDecl);
	dev->SetIndices(iBuf);
	dev->SetStreamSource(0, vBuf, 0, batch->getVertexSize());


	for (unsigned int node = 0; node < nodes.getCount(); node++){

		renderer->changeShaderConstant4x4f("matrix0", getMatrix(node - 1));
		renderer->changeShaderConstant4x4f("matrix1", getMatrix(node));
		renderer->changeShaderConstant4x4f("matrix2", getMatrix(node + 1));
		renderer->changeShaderConstant4x4f("matrix3", getMatrix(node + 2));

		for (unsigned int i = 0; i < nodes[node].nRails; i++){
			renderer->changeShaderConstant4f("range", vec4(float(i) / nodes[node].nRails, float(i + 1) / nodes[node].nRails, 1, 1));
			dev->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, batch->getVertexCount(), 0, batch->getIndexCount() / 3);
		}
	}


	renderer->setTextures(noise);
	renderer->setShader(woodShader);
	renderer->apply();

	renderer->changeShaderConstant4x4f("view_proj_matrix", mvp);

	dev->SetVertexDeclaration(vDecl);
	dev->SetStreamSource(0, vBuf2, 0, 6 * sizeof(float));

	for (unsigned int i = 0; i < nodes.getCount(); i++){
		if (nodes[i].pillar){
			renderer->changeShaderConstant3f("position", nodes[i].position);
			dev->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 32);
		}
	}
}

mat4 Rail::getMatrix(int x) const {
	x = getIndex(x);

	mat4 mat(
		1, 0, 0, 0,
		0, 1, 0, 0,
		0, 0, 1, 0,
		0, 0, 0, 1);

	mat.translate(nodes[x].position);
	mat = mat * rotateZXY(nodes[x].wx, nodes[x].wy, nodes[x].wz);

	return mat;
}

void Rail::transform(float x, vec4 &position) const {
	int p = (int) x;
	float t = x - float(p);
	
	mat4 m0 = getMatrix(p - 1);
	mat4 m1 = getMatrix(p);
	mat4 m2 = getMatrix(p + 1);
	mat4 m3 = getMatrix(p + 2);

	position = cerp(m0 * position, m1 * position, m2 * position, m3 * position, t);
}


void Rail::getPos(float x, vec3 &position, float &wx, float &wy, float &wz, mat4 &mdl) const {
	vec4 center(0, 0, 0, 1);
	vec4 front(0, 0, 0, 1);
	vec4 up(0, 30, 0, 1);

	transform(x, center);
	transform(x + 0.01f, front);
	transform(x, up);

	vec3 dir = up.xyz() - center.xyz();
	position = center.xyz() + 30 * normalize(dir);

	vec3 v0 = normalize(front.xyz() - center.xyz());
	vec3 v1 = normalize(up.xyz() - center.xyz());
	vec3 v2 = normalize(cross(v1, v0));
	
	v1 = cross(v0, v2);

	mdl.elem[0][0] = v2.x;
	mdl.elem[0][1] = v2.y;
	mdl.elem[0][2] = v2.z;
	mdl.elem[0][3] = 0;
	mdl.elem[1][0] = v1.x;
	mdl.elem[1][1] = v1.y;
	mdl.elem[1][2] = v1.z;
	mdl.elem[1][3] = 0;
	mdl.elem[2][0] = v0.x;
	mdl.elem[2][1] = v0.y;
	mdl.elem[2][2] = v0.z;
	mdl.elem[2][3] = 0;
	mdl.elem[3][0] = 0;
	mdl.elem[3][1] = 0;
	mdl.elem[3][2] = 0;
	mdl.elem[3][3] = 1;


	// t = 4 * t * t * t - 6 * t * t + 3 * t;
	// t = t * (3 + t * (4 * t - 6));
}

bool Rail::loadFromFile(char *fileName){
	unsigned int len;
	
	FILE *file = fopen(fileName, "rb");
	if (file == NULL) return false;

	fread(&len, sizeof(len), 1, file);
	nodes.setCount(len);
	
	fread(nodes.getArray(), len * sizeof(Node), 1, file);
	/*for (unsigned int i = 0; i < len; i++){
		fread(((char *) nodes.getArray()) + i * sizeof(Node), 7 * 4, 1, file);
		nodes[i].pillar = true;
	}*/
	for (unsigned int i = 0; i < len; i++){
		float dist = length(nodes[i].position - nodes[(i + 1) % len].position);
		nodes[i].nRails = (int) (0.012f * dist);
	}

	nodes[24].pillar = false;
	nodes[25].pillar = false;
	nodes[26].pillar = false;
	nodes[27].pillar = false;

	fclose(file);

	return true;
}

bool Rail::saveToFile(char *fileName){
	FILE *file = fopen(fileName, "wb");
	if (file == NULL) return false;

	unsigned len = nodes.getCount();
	fwrite(&len, sizeof(len), 1, file);
	fwrite(nodes.getArray(), len * sizeof(Node), 1, file);
	fclose(file);

	return true;
}
