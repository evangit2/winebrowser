#include "../Framework2/Direct3D/Direct3DApp.h"

#include "../Framework2/Util/ParticleSystem.h"
#include "../Framework2/Math/PerlinNoise.h"

#include "Rail.h"

D3DVERTEXELEMENT9 particleVF[] = {
	{ 0, 0,                           D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0},
	{ 0, sizeof(vec3),                D3DDECLTYPE_FLOAT2, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0},
	{ 0, sizeof(vec3) + sizeof(vec2), D3DDECLTYPE_FLOAT4, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_COLOR,    0},
	D3DDECL_END()
};

/*
D3DVERTEXELEMENT9 particleVF[] = {
	{ 0, 0,                            D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0},
	{ 0, sizeof(vec3),                 D3DDECLTYPE_FLOAT1, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_PSIZE,    0},
	{ 0, sizeof(vec3) + sizeof(float), D3DDECLTYPE_FLOAT4, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_COLOR,    0},
	D3DDECL_END()
};*/

D3DVERTEXELEMENT9 terrainVF[] = {
	{ 0, 0,                D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0},
	{ 0, sizeof(vec3),     D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_NORMAL,   0},
	{ 0, sizeof(vec3) * 2, D3DDECLTYPE_FLOAT2, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0},
	D3DDECL_END()
};

class Particles : public ParticleSystem {
protected:
	void initParticle(Particle &p){
		p.pos = pos;

		float x, z;
		do {
			x = float(rand()) / RAND_MAX - 0.5f;
			z = float(rand()) / RAND_MAX - 0.5f;
		} while (x * x + z * z > 0.5 * 0.5);

		float tx = 4000.0f * x;
		float tz = 2500.0f * z;

		p.pos.x += tx * cosf(0.7f) + tz * -sinf(0.7f);
		p.pos.z += tx * sinf(0.7f) + tz * cosf(0.7f);

		p.dir = vec3(0, 1, 0);
		p.dir *= random(speed, speedSpread);
		p.size = random(size, sizeSpread);
		p.initialLife =	p.life = random(life, lifeSpread);
	}
};

class Particles2 : public ParticleSystem {
protected:
	void initParticle(Particle &p){
		p.pos = pos;
		p.pos.z += 1000 * (float(rand()) / RAND_MAX - 0.5f);

		p.dir = vec3(-1, -0.6f, -0.1f);
		p.dir *= random(speed, speedSpread);
		p.size = random(size, sizeSpread);
		p.initialLife =	p.life = random(life, lifeSpread);
	}
};

class MainApp : public Direct3DApp {
public:
	void setKey(unsigned int key, bool value);
	//void resetCamera();

	bool load();
	bool unload();
	bool init();
	bool exit();

	void drawSkyBox();
	void drawLava();
	void drawWater();
	void drawTerrain();
	void drawParticles(ParticleSystem *pSystem);
	bool drawFrame();
protected:
	TextureID particle, noise, environment, flame, waterEnvironment, shadow;

	Rail rail;

	Particles *pSystem0;
	ParticleSystem *pSystem1;
	LPDIRECT3DVERTEXDECLARATION9 particleVDecl;
	LPDIRECT3DVERTEXDECLARATION9 terrainVDecl;

	ShaderID terrShader, lavaShader, waterShader;
	LPDIRECT3DVERTEXBUFFER9 vTerrBuf;
	LPDIRECT3DINDEXBUFFER9 iTerrBuf;

	bool demoMode;
};

void MainApp::setKey(unsigned int key, bool value){
	App::setKey(key, value);

	if (value){
		/*if (key == KEY_INSERT){
			rail.addNode(Node(20, position, wx, wy, wz));
		} else */if (key == demoModeKey){
			demoMode = !demoMode;
		}/* else if (key == 'O'){
			rail.loadFromFile("Path.pth");
		} else if (key == 'S'){
			rail.saveToFile("Path.pth");
		} else if (key == KEY_BACKSPACE){
			rail.removeLastNode();
		} else if (key >= '3' && key <= '8'){
			static float Wx[6] = { 0, 0, -PI / 2, PI / 2, 0, 0 };
			static float Wy[6] = { -PI / 2, PI / 2, 0, 0, 0, PI };

			wx = Wx[key - '3'];
			wy = Wy[key - '3'];
			wz = 0;
		}*/
	}
}
/*
void MainApp::resetCamera(){
	position = vec3(0, 0, 3000);
	wx = 0;
	wy = 0;
	wz = 0;
}
*/
bool MainApp::init(){
	pSystem0 = new Particles();
	pSystem0->setSpawnRate(200);
	pSystem0->setSpeed(150, 120);
	pSystem0->setLife(5.0f, 0);
	pSystem0->setDirectionalForce(vec3(0, -10, 0));
	//pSystem0->setDirectionalForce(vec3(0, 0, 0));
	pSystem0->setFrictionFactor(0.95f);
	pSystem0->setPosition(vec3(3000, -1200, 3400));
	pSystem0->setSize(130, 40);
	for (unsigned i = 0; i < 11; i++){
		pSystem0->setColor(i, vec4(i / 11.0f, i / 50.0f, 0, 0));
	}
	pSystem0->setColor(i, vec4(0, 0, 0, 0));

	pSystem1 = new Particles2();
	pSystem1->setSpawnRate(150);
	pSystem1->setSpeed(400, 120);
	pSystem1->setLife(7.0f, 0);
	//pSystem1->setDirectionalForce(vec3(-50, -200, 0));
	pSystem1->setFrictionFactor(0.95f);
	pSystem1->setPosition(vec3(7700, 500, 4800));
	pSystem1->setSize(70, 20);
	//pSystem1->setColorScheme(COLOR_SCHEME_SMOKE);
	for (i = 0; i < 11; i++){
		pSystem1->setColor(i, vec4(i / 11.0f, i / 50.0f, 0, 0));
	}
	pSystem1->setColor(i, vec4(0, 0, 0, 0));




	initPerlin();

	return true;
}

bool MainApp::exit(){
	delete pSystem0;
	delete pSystem1;

	return true;
}

#define LOAD_TEXTURE(var, s) if ((var = renderer->addTexture(s)) == TEXTURE_NONE) return false;
#define LOAD_SHADER(var, s)  if ((var = renderer->addShader (s)) == SHADER_NONE)  return false;

struct TerrVertex {
	vec3 vertex;
	vec3 normal;
	vec2 texCoord;
};

#define TERR_SIZE 257
#define CLAMP(x) min(x, TERR_SIZE - 1)

bool MainApp::load(){
	if (caps.PixelShaderVersion < D3DPS_VERSION(2,0) || caps.VertexShaderVersion < D3DVS_VERSION(2,0)){
		String error("This demo requires pixel and vertex shader version 2.0.\n"
					 "Your card and driver only supports pixel shader ");
		error.sprintf("%d.%d", (caps.PixelShaderVersion  >> 8) & 255, caps.PixelShaderVersion  & 255);
		error += " and vertex shader ";
		error.sprintf("%d.%d", (caps.VertexShaderVersion >> 8) & 255, caps.VertexShaderVersion & 255);

		addToLog(error);		
		return false;
	}

	setDefaultFont("../Textures/Fonts/Future.font", "../Textures/Fonts/Future.dds");

	LOAD_TEXTURE(particle, "../Textures/Particle.jpg");

	dev->CreateVertexDeclaration(particleVF, &particleVDecl);
	dev->CreateVertexDeclaration(terrainVF, &terrainVDecl);

	unsigned short *buf = new unsigned short[TERR_SIZE * TERR_SIZE];
	FILE *file = fopen("terrain.raw", "rb");
	fread(buf, TERR_SIZE * TERR_SIZE * sizeof(short), 1, file);
	fclose(file);

	LOAD_TEXTURE(shadow, "shadow.jpg");

	unsigned int x, y, z;
	union {
		void *dsst;
		TerrVertex *dst;
		unsigned int *idest;
	};

	dev->CreateVertexBuffer(TERR_SIZE * TERR_SIZE * sizeof(TerrVertex), D3DUSAGE_WRITEONLY, 0, D3DPOOL_MANAGED, &vTerrBuf, NULL);
	vTerrBuf->Lock(0, 0, &dsst, 0);
	for (z = 0; z < TERR_SIZE; z++){
		for (x = 0; x < TERR_SIZE; x++){
			dst->vertex = 30 * vec3(2.0f * x - TERR_SIZE, 0.002f * buf[z * TERR_SIZE + x] - 50, 2.0f * z - TERR_SIZE);

			vec3 normal = vec3(float(buf[z * TERR_SIZE + CLAMP(x+1)]) - float(buf[z * TERR_SIZE + x]),
							   2500,
							   -float(buf[CLAMP(z+1) * TERR_SIZE + x]) + float(buf[z * TERR_SIZE + x]));

			dst->normal = normalize(normal);
			dst->texCoord = vec2(float(x) / TERR_SIZE, 1.0f - float(z) / TERR_SIZE);
			dst++;
		}
	}
	vTerrBuf->Unlock();
	delete buf;


	dev->CreateIndexBuffer((TERR_SIZE - 1) * (TERR_SIZE * 2 + 1) * sizeof(int), D3DUSAGE_WRITEONLY, D3DFMT_INDEX32, D3DPOOL_MANAGED, &iTerrBuf, NULL);
	iTerrBuf->Lock(0, 0, &dsst, 0);

	int base = 0;
	for (int j = 1; j < TERR_SIZE; j++){
		if (j & 1){
			for (int i = 0; i < TERR_SIZE; i++){
				*idest++ = base + i;
				*idest++ = base + i + TERR_SIZE;
			}
			*idest++ = base + TERR_SIZE - 1 + TERR_SIZE;
		} else {
			for (int i = TERR_SIZE - 1; i >= 0; i--){
				*idest++ = base + i;
				*idest++ = base + i + TERR_SIZE;
			}
			*idest++ = base + TERR_SIZE;
		}
		base += TERR_SIZE;
	}
	iTerrBuf->Unlock();

	LOAD_SHADER(terrShader,  "TerrainShader.shd");
	LOAD_SHADER(lavaShader,  "LavaShader.shd");
	LOAD_SHADER(waterShader, "WaterShader.shd");

	flame = renderer->addTexture("../Textures/Flame.tga", TEX_CLAMP);



#define SIZE 32
#define RANGE 3.37f

	unsigned int maxVal = 0, minVal = 255;

	unsigned char *noiseImg = new unsigned char[SIZE * SIZE * SIZE];
	unsigned char *dest = noiseImg;
	for (z = 0; z < SIZE; z++){
		for (y = 0; y < SIZE; y++){
			for (x = 0; x < SIZE; x++){
				unsigned char val = (unsigned char) (127.5f + 127.5f * tileableTurbulence3(x * RANGE / SIZE, y * RANGE / SIZE, z * RANGE / SIZE, RANGE, RANGE, RANGE, 12));
				*dest++ = val;
				if (val > maxVal) maxVal = val;
				if (val < minVal) minVal = val;
			}
		}
	}
	dest = noiseImg;
	for (z = 0; z < SIZE; z++)
		for (y = 0; y < SIZE; y++)
			for (x = 0; x < SIZE; x++)
				*dest++ = (255 * (*dest - minVal)) / (maxVal - minVal);

	Image3D *image = new Image3D();
	image->loadFromMemory(noiseImg, SIZE, SIZE, SIZE, FORMAT_I8, true, false);
	noise = renderer->addTexture3D(image, TEX_NOMIPMAPPING);


	environment = renderer->addCubemap(
		"../Textures/CubeMaps/Tidepool/tidepool_negx.jpg", 
		"../Textures/CubeMaps/Tidepool/tidepool_posx.jpg", 
		"../Textures/CubeMaps/Tidepool/tidepool_negy.jpg", 
		"../Textures/CubeMaps/Tidepool/tidepool_posy.jpg", 
		"../Textures/CubeMaps/Tidepool/tidepool_negz.jpg", 
		"../Textures/CubeMaps/Tidepool/tidepool_posz.jpg");

	waterEnvironment = renderer->addCubemap(
		"negx.jpg",
		"posx.jpg",
		"negy.jpg",
		"posy.jpg",
		"negz.jpg",
		"posz.jpg");

	if (!rail.load(dev, renderer)) return false;
	demoMode = true;
	rail.loadFromFile("Path.pth");

	return true;
}

bool MainApp::unload(){
	particleVDecl->Release();

	vTerrBuf->Release();
	iTerrBuf->Release();
	terrainVDecl->Release();

	rail.unload();

	return true;
}

void MainApp::drawSkyBox(){
	renderer->setDepthFunc(DEPTH_NONE);
	renderer->setMask(COLOR);
	renderer->setTextures(environment);
	renderer->apply();

	struct Vertex {
		vec3 position;
		unsigned int color;
		vec3 texCoord;
	};

	Vertex vertices[8];

	vertices[0].position = vec3(-5,  5,  5);
	vertices[1].position = vec3( 5,  5,  5);
	vertices[2].position = vec3(-5, -5,  5);
	vertices[3].position = vec3( 5, -5,  5);
	vertices[4].position = vec3(-5,  5, -5);
	vertices[5].position = vec3( 5,  5, -5);
	vertices[6].position = vec3(-5, -5, -5);
	vertices[7].position = vec3( 5, -5, -5);

	for (unsigned int i = 0; i < 8; i++){
		vertices[i].texCoord = vertices[i].position;
		vertices[i].color = 0x44444444;
		//vertices[i].color = 0x99999999;
	}


	static short indices[] = {0,1,2,  1,3,2,  1,5,3,  5,7,3,  5,4,7,  4,6,7,  4,0,6,  0,2,6,  4,5,0,  5,1,0,  2,3,6,  3,7,6};

	dev->SetFVF(D3DFVF_XYZ | D3DFVF_DIFFUSE | D3DFVF_TEXCOORDSIZE3(0) | (1 << D3DFVF_TEXCOUNT_SHIFT));
	dev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, sizeof(indices) / sizeof(short), 12, indices, D3DFMT_INDEX16, vertices, sizeof(Vertex));
}

void MainApp::drawLava(){
	renderer->setTextures(noise, flame);
	renderer->setShader(lavaShader);
	renderer->apply();

	struct Vertex {
		vec3 position;
		vec3 noiseCoord0;
		vec3 noiseCoord1;
		vec3 coord;
	};

	Vertex verts[4];

	for (unsigned int j = 0; j < 2; j++){
		if (j == 0){
			verts[0].position = vec3(5200, -1300, 1500);
			verts[1].position = vec3( 750, -1300, 1500);
			verts[2].position = vec3( 750, -1300, 5300);
			verts[3].position = vec3(5200, -1300, 5300);
		} else {
			verts[0].position = vec3(7600,   400, 5500);
			verts[1].position = vec3(7600,   400, 3600);
			verts[2].position = vec3(4800, -1300, 3600);
			verts[3].position = vec3(4800, -1300, 5500);
		}

		for (unsigned int i = 0; i < 4; i++){
			verts[i].noiseCoord0 = 0.0005f * verts[i].position;
			verts[i].noiseCoord0.y += 0.05f * time;
			verts[i].noiseCoord1 = verts[i].noiseCoord0 + 0.5f;
			verts[i].coord = 0.0008f * verts[i].position;
			verts[i].coord.y += 0.05f * time;
		}

		dev->SetFVF(D3DFVF_XYZ | D3DFVF_TEXCOORDSIZE3(0) | D3DFVF_TEXCOORDSIZE3(1) | D3DFVF_TEXCOORDSIZE3(2) | (3 << D3DFVF_TEXCOUNT_SHIFT));
		dev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, verts, sizeof(Vertex));
	}
}

void MainApp::drawWater(){
	renderer->setTextures(noise, waterEnvironment);
	renderer->setShader(waterShader);
	renderer->setBlending(SRC_ALPHA, ONE_MINUS_SRC_ALPHA);
	renderer->apply();

	renderer->changeShaderConstant4x4f("view_proj_matrix", projection * modelView);
	renderer->changeShaderConstant3f("camPos", position);
	renderer->changeShaderConstant3f("time", time);

	vec3 verts[4];

	verts[0] = vec3(-5000, -600, 2800);
	verts[1] = vec3(-2250, -600, 2800);
	verts[2] = vec3(-2200, -600,  900);
	verts[3] = vec3(-5000, -600,  900);

	dev->SetFVF(D3DFVF_XYZ);
	dev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, verts, sizeof(vec3));
}

void MainApp::drawTerrain(){
	renderer->setTextures(noise, shadow);
	renderer->setShader(terrShader);
	renderer->apply();

	renderer->changeShaderConstant4x4f("view_proj_matrix", projection * modelView);

	dev->SetVertexDeclaration(terrainVDecl);
	dev->SetIndices(iTerrBuf);
	dev->SetStreamSource(0, vTerrBuf, 0, sizeof(TerrVertex));

	dev->DrawIndexedPrimitive(D3DPT_TRIANGLESTRIP, 0, 0, TERR_SIZE * TERR_SIZE, 0, (TERR_SIZE - 1) * (TERR_SIZE * 2 + 1) - 2);
}

void MainApp::drawParticles(ParticleSystem *pSystem){

	renderer->setMask(COLOR);
	renderer->setTextures(particle);
	renderer->setBlending(ONE, ONE);
	renderer->apply();

	pSystem->update(time);

	vec3 dx(modelView.elem[0][0], modelView.elem[0][1], modelView.elem[0][2]);
	vec3 dy(modelView.elem[1][0], modelView.elem[1][1], modelView.elem[1][2]);

	char *vArray = pSystem->getVertexArray(dx, dy);
	unsigned short *iArray = pSystem->getIndexArray();

	dev->SetVertexDeclaration(particleVDecl);
	dev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, 6 * pSystem->getParticleCount(), 2 * pSystem->getParticleCount(), iArray, D3DFMT_INDEX16, vArray, sizeof(vec3) + sizeof(vec2) + 1 * sizeof(vec4));



/*	char *vArray = pSystem->getPointSpriteArray();

	dev->SetRenderState(D3DRS_POINTSPRITEENABLE, TRUE);
	dev->SetRenderState(D3DRS_POINTSCALEENABLE,  TRUE);


	float a = 0.0f;
	float b = 1000.5f;
	float c = 0.0f;

	float minS = 0.0f;
	float maxS = caps.MaxPointSize;

	dev->SetRenderState(D3DRS_POINTSCALE_A, *((DWORD *) &a));
	dev->SetRenderState(D3DRS_POINTSCALE_B, *((DWORD *) &b));
	dev->SetRenderState(D3DRS_POINTSCALE_C, *((DWORD *) &c));
	dev->SetRenderState(D3DRS_POINTSIZE_MIN, *((DWORD *) &minS));
	dev->SetRenderState(D3DRS_POINTSIZE_MAX, *((DWORD *) &maxS));

	dev->SetVertexDeclaration(particleVDecl);
	dev->DrawPrimitiveUP(D3DPT_POINTLIST, pSystem->getParticleCount(), vArray, sizeof(vec3) + sizeof(float) + sizeof(vec4));

	dev->SetRenderState(D3DRS_POINTSPRITEENABLE, FALSE);
*/
}

bool MainApp::drawFrame(){
	dev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);

	//if (keys['1']) wz += frameTime;
	//if (keys['2']) wz -= frameTime;

	//rail.setContinuous(demoMode);
	rail.setContinuous(true);

	if (demoMode){
		rail.getPos(time, position, wx, wy, wz, modelView);
	} else {
		modelView = rotateZXY(-wx, -wy, -wz);
	}


    dev->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_RGBA(0, 0, 0, 0), 1.0f, 0);

	projection = projectionMatrixX(PI / 2, 1, 1, 30000);

	dev->SetTransform(D3DTS_VIEW,       (D3DMATRIX *) (const float *) transpose(modelView));
	dev->SetTransform(D3DTS_PROJECTION, (D3DMATRIX *) (const float *) transpose(projection));

	drawSkyBox();

	modelView.translate(-position);
	dev->SetTransform(D3DTS_VIEW, (D3DMATRIX *) (const float *) transpose(modelView));


	drawTerrain();
	drawLava();

	drawWater();
	rail.draw(dev, renderer, projection * modelView, position, environment, noise);

	drawParticles(pSystem0);
	drawParticles(pSystem1);

	return true;
}

App *app = new MainApp();
