#ifndef _RAIL_H_
#define _RAIL_H_

#include "../Framework2/Direct3D/Direct3DRenderer.h"
#include "../Framework2/Util/Model.h"

struct Node {
	unsigned int nRails;
	vec3 position;
	float wx, wy, wz;
	bool pillar;

	Node(unsigned int rails, const vec3 &pos, float Wx, float Wy, float Wz){
		nRails = rails;
		position = pos;
		wx = Wx;
		wy = Wy;
		wz = Wz;
	}
};

class Rail {
public:
	bool load(LPDIRECT3DDEVICE9 dev, Renderer *renderer);
	bool unload();

	void draw(LPDIRECT3DDEVICE9 dev, Renderer *renderer, const mat4 &mvp, const vec3 &position, TextureID env, TextureID noise);

	void addNode(const Node &node){ nodes.add(node); }
	void removeLastNode(){ if (nodes.getCount()) nodes.remove(nodes.getCount() - 1); }

	mat4 getMatrix(int x) const;
	void transform(float x, vec4 &position) const;
	void getPos(float x, vec3 &position, float &wx, float &wy, float &wz, mat4 &mdl) const;

	bool loadFromFile(char *fileName);
	bool saveToFile(char *fileName);

	void setContinuous(bool val){ continuous = val; }

private:
	int getIndex(int x) const {	return continuous? (x + nodes.getCount()) % nodes.getCount() : min(max(x, 0), (int) nodes.getCount() - 1); }
	bool continuous;

	Set <Node> nodes;

	ShaderID railShader, woodShader;
	LPDIRECT3DVERTEXDECLARATION9 vDecl;

	LPDIRECT3DVERTEXBUFFER9 vBuf;
	LPDIRECT3DINDEXBUFFER9 iBuf;

	LPDIRECT3DVERTEXBUFFER9 vBuf2;

	Model *model;
};

#endif