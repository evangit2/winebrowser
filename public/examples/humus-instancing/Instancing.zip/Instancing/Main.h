#include "../Framework2/Direct3D/Direct3DApp.h"
#include "../Framework2/Util/ParticleSystem.h"

D3DVERTEXELEMENT9 vertexFormat[] = {
	{ 0, 0,            D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0 },
	{ 0, sizeof(vec3), D3DDECLTYPE_FLOAT2, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0 },

	{ 1, 0,                D3DDECLTYPE_FLOAT4, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 1 },
	{ 1, sizeof(vec4),     D3DDECLTYPE_FLOAT4, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 2 },
	{ 1, sizeof(vec4) * 2, D3DDECLTYPE_FLOAT4, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 3 },
	{ 1, sizeof(vec4) * 3, D3DDECLTYPE_FLOAT4, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 4 },
	{ 1, sizeof(vec4) * 4, D3DDECLTYPE_FLOAT4, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 5 },
	{ 1, sizeof(vec4) * 5, D3DDECLTYPE_FLOAT4, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 6 },
	{ 1, sizeof(vec4) * 6, D3DDECLTYPE_FLOAT4, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 7 },
	{ 1, sizeof(vec4) * 7, D3DDECLTYPE_FLOAT4, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 8 },
	D3DDECL_END()
};

D3DVERTEXELEMENT9 vertexFormatNoInst[] = {
	{ 0, 0,                           D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0 },
	{ 0, sizeof(vec3),                D3DDECLTYPE_FLOAT2, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0 },
	{ 0, sizeof(vec3) + sizeof(vec2), D3DDECLTYPE_FLOAT4, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 1 },
	D3DDECL_END()
};

D3DVERTEXELEMENT9 vertexFormatConstInst[] = {
	{ 0, 0,            D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0 },
	{ 0, sizeof(vec3), D3DDECLTYPE_FLOAT2, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0 },
	D3DDECL_END()
};

struct Vertex {
	vec3 pos;
	vec2 texCoord;
};

struct Instance {
	vec3 position;
	float size;
	vec4 color;
};

struct VertexNoInst {
	vec3 pos;
	vec2 texCoord;
	vec4 color;
};

#define INSTANCING       0
#define CONST_INSTANCING 1
#define VB_UPLOAD        2
#define USER_POINTER     3
#define NAIVE            4

class MainApp : public Direct3DApp {
public:
	void setKey(unsigned int key, bool value);

	void resetCamera();

	bool init();
	bool exit();

	bool load();
	bool unload();

	bool releaseDPRes();
	bool createDPRes();

	void drawParticleSystem();
	bool drawFrame();
protected:
	ParticleSystem *pSystem;

	LPDIRECT3DVERTEXDECLARATION9 vDecl, vDeclNoInst, vDeclConstInst;
	LPDIRECT3DVERTEXBUFFER9 vBuf0;
	LPDIRECT3DVERTEXBUFFER9 vBuf1;
	LPDIRECT3DINDEXBUFFER9  iBuf;

	LPDIRECT3DVERTEXBUFFER9 vBufNoInst;
	LPDIRECT3DINDEXBUFFER9  iBufNoInst;

	unsigned int bufferSize, bufferSizeNoInst;
	bool indexBufferFilled;

	TextureID particle;
	ShaderID shader, shaderNoInst, shaderConstInst;

	unsigned int path;
	float spawnRate;

	bool supportsInstancing, supportsVS_2_0;
};
