#include "Main.h"
#include <stdio.h>

void MainApp::setKey(unsigned int key, bool value){
	if (value && key >= '1' && key <= '5'){
		if (key > '2' || (supportsInstancing && key == '1') || (supportsVS_2_0 && key == '2')) path = key - '1';
	}
	
	App::setKey(key, value);
}

void MainApp::resetCamera(){
	position = vec3(0, 100, -400);
	wx = 0;
	wy = 0;
	wz = 0;
}

bool MainApp::init(){
    spawnRate = 6000;

	pSystem = new ParticleSystem();
	pSystem->setSize(5, 2);
	pSystem->setSpeed(100, 50);
	pSystem->setSpawnRate(spawnRate);
	pSystem->setFrictionFactor(1.0f);
/*	PointForce pf;
	pf.pos = vec3(0,0,0);
	pf.linearAttenuation = 0;
	pf.quadraticAttenuation = 1.0f;
	pf.strength = 100000.0f;
	pSystem->addPointForce(pf);
*/
//	pSystem->setDirectionalForce(vec3(0, -100, 0));

	bufferSize = 2048;
	bufferSizeNoInst = 2048;

	path = INSTANCING;

	return true;
}

bool MainApp::exit(){
	delete pSystem;
	return true;
}

bool MainApp::load(){
	unsigned int i;

	if (caps.PixelShaderVersion < D3DPS_VERSION(1, 1) || caps.VertexShaderVersion < D3DVS_VERSION(1, 1)){
		String error("This demo requires pixel shader 1.1 and vertex shader 1.1.\n"
					 "Your card/driver only supports pixel shader ");
		error.sprintf("%d.%d", (caps.PixelShaderVersion  >> 8) & 255, caps.PixelShaderVersion  & 255);
		error += " and vertex shader ";
		error.sprintf("%d.%d", (caps.VertexShaderVersion >> 8) & 255, caps.VertexShaderVersion & 255);

		addToLog(error);
		return false;
	}

	createDPRes();

	supportsVS_2_0 = caps.VertexShaderVersion >= D3DVS_VERSION(2, 0);

	if (!supportsInstancing && path == INSTANCING) path = CONST_INSTANCING;
	if (!supportsVS_2_0 && path == CONST_INSTANCING) path = VB_UPLOAD;

	setDefaultFont("../Textures/Fonts/Future.font", "../Textures/Fonts/Future.dds");

	if (supportsInstancing){
		if ((shader = renderer->addShader("shader.shd")) == SHADER_NONE) return false;
	}
	if ((shaderNoInst = renderer->addShader("shaderNoInst.shd")) == SHADER_NONE) return false;
	if (supportsVS_2_0){
		if ((shaderConstInst = renderer->addShader("shaderConstInst.shd")) == SHADER_NONE) return false;
	}

	if ((particle = renderer->addTexture("../Textures/Particle.tga")) == TEXTURE_NONE) return false;

	Vertex *vArray;
	vBuf0->Lock(0, 0, (void **) &vArray, 0);
	for (i = 0; i < 64; i++){
		vArray[0].pos = vec3(-1, -1, float(i));
		vArray[0].texCoord = vec2(0, 0);
		vArray[1].pos = vec3( 1, -1, float(i));
		vArray[1].texCoord = vec2(1, 0);
		vArray[2].pos = vec3( 1,  1, float(i));
		vArray[2].texCoord = vec2(1, 1);
		vArray[3].pos = vec3(-1,  1, float(i));
		vArray[3].texCoord = vec2(0, 1);

		vArray += 4;
	}
	vBuf0->Unlock();

	dev->CreateIndexBuffer(64 * 6 * sizeof(unsigned short), D3DUSAGE_WRITEONLY, D3DFMT_INDEX16, D3DPOOL_MANAGED, &iBuf, NULL);
	unsigned short *dest;
	iBuf->Lock(0, 0, (void **) &dest, 0);
	for (i = 0; i < 64; i++){
		*dest++ = 4 * i;
		*dest++ = 4 * i + 1;
		*dest++ = 4 * i + 2;
		*dest++ = 4 * i + 0;
		*dest++ = 4 * i + 2;
		*dest++ = 4 * i + 3;
	}
	iBuf->Unlock();

	dev->CreateVertexDeclaration(vertexFormat, &vDecl);
	dev->CreateVertexDeclaration(vertexFormatNoInst, &vDeclNoInst);
	dev->CreateVertexDeclaration(vertexFormatConstInst, &vDeclConstInst);
	return true;
}

bool MainApp::unload(){
    releaseDPRes();

	iBuf->Release();
	vDecl->Release();
	vDeclNoInst->Release();
	vDeclConstInst->Release();
	return true;
}

bool MainApp::releaseDPRes(){
	vBuf0->Release();
	vBuf1->Release();

	vBufNoInst->Release();
	iBufNoInst->Release();

	return true;
}

bool MainApp::createDPRes(){
	if (caps.VertexShaderVersion >= D3DVS_VERSION(3, 0)){
		supportsInstancing = true;
	} else {
		if (supportsInstancing = (d3d->CheckDeviceFormat(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, D3DFMT_X8R8G8B8, 0, D3DRTYPE_SURFACE, (D3DFORMAT) MAKEFOURCC('I', 'N', 'S', 'T')) == D3D_OK)){
			// Notify the driver that instancing support is expected
			dev->SetRenderState(D3DRS_POINTSIZE, MAKEFOURCC('I', 'N', 'S', 'T'));
		}
	}

	dev->CreateVertexBuffer(4 * 64 * sizeof(Vertex), D3DUSAGE_WRITEONLY | D3DUSAGE_DYNAMIC, 0, D3DPOOL_DEFAULT, &vBuf0, NULL);
	dev->CreateVertexBuffer(bufferSize * sizeof(Instance), D3DUSAGE_WRITEONLY | D3DUSAGE_DYNAMIC, 0, D3DPOOL_DEFAULT, &vBuf1, NULL);

	dev->CreateVertexBuffer(4 * bufferSizeNoInst * sizeof(VertexNoInst), D3DUSAGE_WRITEONLY | D3DUSAGE_DYNAMIC, 0, D3DPOOL_DEFAULT, &vBufNoInst, NULL);
	dev->CreateIndexBuffer(6 * bufferSizeNoInst * sizeof(unsigned short), D3DUSAGE_WRITEONLY | D3DUSAGE_DYNAMIC, D3DFMT_INDEX16, D3DPOOL_DEFAULT, &iBufNoInst, NULL);
	indexBufferFilled = false;

	return true;
}

void MainApp::drawParticleSystem(){
	unsigned int start;
	vec4 posAndSize[64];
	vec4 colors[64];
	char *vArray;
	unsigned short *iArray;
	void *dest;

	pSystem->update(time);

	vec3 dx(modelView.elem[0][0], modelView.elem[0][1], modelView.elem[0][2]);
	vec3 dy(modelView.elem[1][0], modelView.elem[1][1], modelView.elem[1][2]);

	renderer->setShader(path == INSTANCING? shader : path == CONST_INSTANCING? shaderConstInst : shaderNoInst);
	renderer->setTexture("Particle", particle);
	renderer->setBlending(ONE, ONE);
	renderer->setMask(COLOR);
	renderer->setDepthFunc(DEPTH_NONE);
	renderer->apply();

	renderer->changeShaderConstant4x4f("mvp", projection * modelView);

	renderer->changeShaderConstant3f("dx", dx);
	renderer->changeShaderConstant3f("dy", dy);

	switch (path){
	case INSTANCING:
		/********************* Instancing path ************************/
		if (pSystem->getParticleCount() > bufferSize){
			vBuf1->Release();
			bufferSize = pSystem->getParticleCount();
			dev->CreateVertexBuffer(bufferSize * sizeof(Instance), D3DUSAGE_WRITEONLY | D3DUSAGE_DYNAMIC, 0, D3DPOOL_DEFAULT, &vBuf1, NULL);
		}

		vBuf1->Lock(0, 0, &dest, D3DLOCK_DISCARD);
		pSystem->fillInstanceVertexArray((char *) dest);
		vBuf1->Unlock();

		dev->SetVertexDeclaration(vDecl);

		dev->SetStreamSourceFreq(0, (D3DSTREAMSOURCE_INDEXEDDATA | pSystem->getParticleCount() / 4));
		dev->SetStreamSourceFreq(1, (D3DSTREAMSOURCE_INSTANCEDATA | 1));

		dev->SetStreamSource(0, vBuf0, 0, sizeof(Vertex));
		dev->SetStreamSource(1, vBuf1, 0, sizeof(Instance) * 4);

		dev->SetIndices(iBuf);
		dev->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, 16, 0, 8);

		dev->SetStreamSourceFreq(0, 1);
		dev->SetStreamSourceFreq(1, 1);
		break;
	case CONST_INSTANCING:
		/********************* Shader constant instancing *******************/
		dev->SetVertexDeclaration(vDeclConstInst);

		dev->SetStreamSource(0, vBuf0, 0, sizeof(Vertex));
		dev->SetIndices(iBuf);

        start = 0;
		while (start < pSystem->getParticleCount()){
			int nToDraw = min(pSystem->getParticleCount() - start, 64);

			pSystem->fillInstanceVertexArrayRange(posAndSize, colors, start, nToDraw);

			renderer->changeShaderConstantArray4f("posAndSize", posAndSize, nToDraw);
			renderer->changeShaderConstantArray4f("colors", colors, nToDraw);

    		dev->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, nToDraw * 4, 0, nToDraw * 2);

			start += nToDraw;
		}
		break;
	case VB_UPLOAD:
		/********************* Copy to vertex buffer path *******************/

		if (pSystem->getParticleCount() > bufferSizeNoInst){
			vBufNoInst->Release();
			iBufNoInst->Release();

			bufferSizeNoInst = pSystem->getParticleCount();

			dev->CreateVertexBuffer(4 * bufferSizeNoInst * sizeof(VertexNoInst), D3DUSAGE_WRITEONLY | D3DUSAGE_DYNAMIC, 0, D3DPOOL_DEFAULT, &vBufNoInst, NULL);
			dev->CreateIndexBuffer(6 * bufferSizeNoInst * sizeof(unsigned short), D3DUSAGE_WRITEONLY | D3DUSAGE_DYNAMIC, D3DFMT_INDEX16, D3DPOOL_DEFAULT, &iBufNoInst, NULL);
			indexBufferFilled = false;
		}


		vBufNoInst->Lock(0, 0, &dest, D3DLOCK_DISCARD);
		pSystem->fillVertexArray((char *) dest, dx, dy, true, false);
		vBufNoInst->Unlock();

		if (!indexBufferFilled){
			iBufNoInst->Lock(0, 0, &dest, D3DLOCK_DISCARD);
			pSystem->fillIndexArray((unsigned short *) dest);
			iBufNoInst->Unlock();

			indexBufferFilled = true;
		}

		dev->SetVertexDeclaration(vDeclNoInst);

		dev->SetStreamSource(0, vBufNoInst, 0, sizeof(VertexNoInst));
		dev->SetIndices(iBufNoInst);

		dev->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, 4 * pSystem->getParticleCount(), 0, 2 * pSystem->getParticleCount());

		break;
	case USER_POINTER:
		/********************* User pointer vertex array path ********************/

		vArray = pSystem->getVertexArray(dx, dy, true, false);
		iArray = pSystem->getIndexArray();
		
		dev->SetVertexDeclaration(vDeclNoInst);
		dev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, 4 * pSystem->getParticleCount(), 2 * pSystem->getParticleCount(), iArray, D3DFMT_INDEX16, vArray, sizeof(VertexNoInst));
		break;
	case NAIVE:
		/********************* Naive path ***************************************/
		dev->SetVertexDeclaration(vDeclNoInst);
		char *vArray = pSystem->getVertexArray(dx, dy, true, false);
		static unsigned short iArray[6] = { 0, 1, 2, 0, 2, 3 };
		for (unsigned int i = 0; i < pSystem->getParticleCount(); i++){
			dev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, 4, 2, iArray, D3DFMT_INDEX16, vArray + i * 4 * sizeof(VertexNoInst), sizeof(VertexNoInst));
		}
		break;
	}
}

bool MainApp::drawFrame(){
	if (keys[VK_ADD]){
		spawnRate *= powf(0.5f, -frameTime);
	}
	if (keys[VK_SUBTRACT]){
		spawnRate *= powf(0.5f, frameTime);
	}
	pSystem->setSpawnRate(spawnRate);

    dev->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_RGBA(0, 0, 0, 0), 1.0f, 0);

	projection = projectionMatrixX(1.5f, float(height) / float(width), 1, 6000);
	modelView = rotateZXY(-wx, -wy, -wz);
	modelView.translate(-position);

	pSystem->setPosition(vec3(300 * cosf(3.314f * time) * sinf(1.321f * time), 200 * sinf(1.31f * time) * cosf(1.714f * time), 300 * sinf(2.312f * time) * cosf(2.8142f * time)));

	drawParticleSystem();

	if (showFPS){
		renderer->setTextures(textTexture);
		renderer->setBlending(SRC_ALPHA, ONE_MINUS_SRC_ALPHA);
		renderer->apply();

		static const char *paths[] = { "Instancing", "Spare shader constants instancing", "Vertex buffer", "User pointer vertex array", "One draw call per instance" };
		char str[256];
		sprintf(str, "Using path: %s\nDraw calls needed: %d\nParticle count: %d\n", paths[path], path == CONST_INSTANCING? (pSystem->getParticleCount() + 63) / 64 : path == NAIVE? pSystem->getParticleCount() : 1, pSystem->getParticleCount());

		drawText(str, 0, 0.82f, 0.04f, 0.06f);
	}

	return true;
}

App *app = new MainApp();
