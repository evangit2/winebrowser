#pragma once
// Windows SDK PIX events are disabled when USE_PIX is absent.
#define PIXBeginEvent(...) ((void)0)
#define PIXEndEvent(...) ((void)0)
#define PIXSetMarker(...) ((void)0)
