#!/bin/sh
set -eu
cd "$(dirname "$0")"
"${CXX:-i686-w64-mingw32-g++}" '-std=c++17' '-O1' '-fpermissive' '-DUNICODE' '-D_UNICODE' '-DNDEBUG' '-D_XM_NO_INTRINSICS_' '-static' '-static-libgcc' '-static-libstdc++' '-include' './compat.h' '-I./header-compat' '-I./DirectXMath/Inc' '-Wl,--no-insert-timestamp' '-mwindows' '-o' './D3D12Bundles.exe' './D3D12Bundles.cpp' './DXSample.cpp' './FrameResource.cpp' './Main.cpp' './SimpleCamera.cpp' './Win32Application.cpp' './stdafx.cpp' '-ld3d12' '-ldxgi' '-ld3dcompiler' '-ldxguid' '-lshell32'
