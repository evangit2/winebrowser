#include "../Framework2/OpenGL/OpenGLApp.h"
#include "../Framework2/Util/OpenGLModel.h"

struct Sphere {
	vec3 pos;
	float size;
	vec3 dir;
	vec3 color;
};

#define SPHERE_COUNT 7
#define COUNT (SPHERE_COUNT + 1)

#define STR(x) #x
#define DEFINE_STR(x) "#define " #x " " STR(x) "\n"


#define SUBDIV_LEVEL 3
#define POW4(x) (1 << (2 * (x)))
#define SPHERE_SIZE (8 * 3 * POW4(SUBDIV_LEVEL))


class MainApp : public OpenGLApp {
public:
	void resetCamera();
	void processMovement(const vec3 &newPosition);
	void setButton(unsigned int button, bool value);

	bool init();
	bool exit();

	bool load();
	bool unload();

	void doPhysics(const float frameTime);

	void drawRoom(int pass);
	void drawSpheres(int pass);

	void drawLight(const vec3 &lightPos, const float size);
	bool drawFrame();
protected:
	Sphere spheres[COUNT];
	OpenGLModel *model;

	ShaderID room, sphere, shadow, roomAmbient, sphereAmbient;

	TextureID base[3], bump[3];
	TextureID light;
};

